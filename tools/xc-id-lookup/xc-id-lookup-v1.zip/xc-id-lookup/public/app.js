/* xc-id-lookup 工具网页逻辑（vanilla JS）
 * 与本机服务 127.0.0.1:7843 同源通信。
 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const FAAS_URL = 'https://magic.solutionsuite.cn/api/faas/zz28FjWVyIhWV';
  const VIA_LABEL = {
    id_home: '星图ID直达主页',
    douyin_exact: '抖音号精确匹配',
    douyin_fuzzy: '抖音号模糊(排序第一)',
    name_search: '名称搜索(排序第一)',
  };

  const state = {
    loggedIn: false,
    source: 'base',
    baseCtx: null,
    file: null,
    headers: [],
    detected: {},
    items: [],
    results: [],
    lookingUp: false,
    qrTimer: null,
    progTimer: null,
  };

  // ---- 工具函数 ----
  function escapeHtml(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function cleanHandle(v) {
    return String(v == null ? '' : v).replace(/\s+/g, '').replace(/^@+/, '').replace(/@+$/, '').trim();
  }
  async function api(path, opt) {
    const r = await fetch(path, opt || {});
    return await r.json().catch(() => ({ ok: false, error: '响应解析失败（HTTP ' + r.status + '）' }));
  }

  // ---- 健康检查 ----
  async function refreshHealth() {
    const h = await api('/health');
    if (!h) return;
    if (h.version) $('version').textContent = h.version;
    state.loggedIn = !!h.loggedIn;
    const pill = $('loginPill');
    if (h.loggedIn) {
      pill.textContent = '✅ 星图已登录';
      pill.className = 'pill pill-green';
    } else if (h.loginPending) {
      pill.textContent = '⏳ 等待登录…';
      pill.className = 'pill pill-gray';
    } else if (h.cookieCount > 0) {
      pill.textContent = '💾 有登录备份（点登录自动恢复）';
      pill.className = 'pill pill-gray';
    } else {
      pill.textContent = '● 未登录';
      pill.className = 'pill pill-red';
    }
    updateButtons();
    // 互查任务在跑（如页面刚刷新）→ 接续轮询
    if (h.lookup && h.lookup.running && !state.lookingUp) startProgressPolling();
  }

  function updateButtons() {
    const canLookup = state.loggedIn && state.items.length > 0 && !state.lookingUp;
    $('lookupBtn').disabled = !canLookup;
  }

  // ---- 登录 ----
  $('loginBtn').addEventListener('click', async () => {
    const btn = $('loginBtn');
    btn.disabled = true;
    $('loginMsg').textContent = '⏳ 正在启动浏览器，请在弹出的 Chrome/Edge 窗口里完成登录…';
    $('qrBox').classList.add('hidden');

    // 轮询二维码（无头模式会出现）
    stopQrPolling();
    state.qrTimer = setInterval(pollQr, 2500);

    const r = await api('/login', { method: 'POST' });
    stopQrPolling();
    btn.disabled = false;

    if (r && r.ok && r.loggedIn) {
      $('loginMsg').textContent = '✅ 登录成功！可以上传名单开始互查。';
      $('qrBox').classList.add('hidden');
    } else if (r && r.cancelled) {
      $('loginMsg').textContent = '登录已取消。';
    } else if (r && r.needInstall) {
      $('loginMsg').textContent = '⚠️ ' + (r.message || '未找到可用浏览器，请安装 Chrome/Edge 后重试。');
    } else {
      $('loginMsg').textContent = '⚠️ ' + ((r && r.message) || '登录未完成，请重试。');
    }
    refreshHealth();
  });

  async function pollQr() {
    const r = await api('/login/qr');
    if (r && r.qr) {
      $('qrImg').src = r.qr;
      $('qrBox').classList.remove('hidden');
      $('loginMsg').textContent = '⏳ 企业策略禁止弹窗，已改为二维码登录，请用手机抖音扫码…';
    }
  }
  function stopQrPolling() {
    if (state.qrTimer) { clearInterval(state.qrTimer); state.qrTimer = null; }
  }

  // ---- 文件上传 / 解析 ----
  function bindDropzone() {
    const drop = $('drop');
    const input = $('fileInput');
    input.addEventListener('change', () => { if (input.files[0]) handleFile(input.files[0]); });
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => {
      e.preventDefault(); drop.classList.add('drag');
    }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => {
      e.preventDefault(); drop.classList.remove('drag');
    }));
    drop.addEventListener('drop', (e) => {
      const f = e.dataTransfer.files[0];
      if (f) handleFile(f);
    });
  }

  async function handleFile(file) {
    if (!/\.(xlsx|xls|csv)$/i.test(file.name)) {
      alert('仅支持 .xlsx / .xls / .csv 文件。');
      return;
    }
    state.file = file;
    const buf = await file.arrayBuffer();
    const r = await api('/parse?fn=' + encodeURIComponent(file.name), {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: buf,
    });
    if (!r || !r.ok) {
      alert((r && r.error) || '解析失败，请检查文件格式。');
      return;
    }
    state.items = parseItemsLocally(buf);
    state.headers = r.headers || [];
    state.detected = r.detected || {};
    renderParseInfo(r, file);
    // 重置上一轮结果
    state.results = [];
    renderResults();
    updateButtons();
  }

  // 本地按检测到的列解析全量行（口径与服务端 parseListBuffer 一致，仅用于取回完整 items）
  function parseItemsLocally(buf) {
    const wb = XLSX.read(buf, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '', raw: false });
    const d = state.detected || {};
    const dyK = d.douyinKey, idK = d.idKey, nmK = d.nameKey;
    const items = [];
    rows.forEach((r, i) => {
      let id = idK ? String(r[idK] || '').trim() : '';
      let douyin = dyK ? String(r[dyK] || '').trim() : '';
      let name = nmK ? String(r[nmK] || '').trim() : '';
      if (!dyK && !idK && nmK) {
        const v = String(r[nmK] || '').trim();
        if (/^\d{12,}$/.test(cleanHandle(v))) id = (v.match(/\d+/) || [''])[0];
        else douyin = v;
        name = '';
      } else {
        if (id) id = ((id.match(/\d+/) || [''])[0]) || cleanHandle(id);
        if (!idK && douyin && /^\d{12,}$/.test(cleanHandle(douyin))) {
          id = (douyin.match(/\d+/) || [''])[0]; douyin = '';
        } else douyin = cleanHandle(douyin);
        name = cleanHandle(name);
      }
      if (!id && !douyin && !name) return;
      items.push({ row: i + 1, id, douyin, name, orig: r });
    });
    return items;
  }

  function renderParseInfo(r, file) {
    $('parseInfo').classList.remove('hidden');
    $('rowCount').textContent = r.count;
    $('fileName').textContent = '（' + file.name + '）';
    setChip('chipDy', r.detected.douyinKey);
    setChip('chipId', r.detected.idKey);
    setChip('chipNm', r.detected.nameKey);
  }
  function setChip(id, val) {
    const el = $(id);
    const label = { chipDy: '抖音号列', chipId: '星图ID列', chipNm: '名称列' }[id];
    el.textContent = label + '：' + (val || '未识别（将用其他列）');
    el.classList.toggle('chip-on', !!val);
  }

  // ---- 开始互查 ----
  $('lookupBtn').addEventListener('click', async () => {
    const r = await api('/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: state.items }),
    });
    if (!r || !r.ok) {
      alert((r && r.error) || '启动失败，请重试。');
      if (r && r.needInstall) refreshHealth();
      return;
    }
    state.results = [];
    renderResults();
    state.lookingUp = true;
    $('lookupMsg').textContent = '⏳ 互查进行中…';
    $('progressBox').classList.remove('hidden');
    updateButtons();
    startProgressPolling();
  });

  function startProgressPolling() {
    if (state.progTimer) clearInterval(state.progTimer);
    pollProgress();
    state.progTimer = setInterval(pollProgress, 1000);
  }

  async function pollProgress() {
    const since = state.results.length;
    const r = await api('/progress?since=' + since);
    if (!r) return;
    const total = r.total || 0;
    const done = r.done || 0;
    $('progressBar').style.width = total ? (done / total * 100).toFixed(1) + '%' : '0%';
    $('progressText').textContent = done + ' / ' + total;
    $('phaseText').textContent = r.phase ? (r.current ? ('第 ' + r.current + ' 行 · ' + r.phase) : r.phase) : '';

    if (Array.isArray(r.results) && r.results.length) {
      state.results = state.results.concat(r.results);
      renderResults();
    }

    if (!r.running && done >= total && total > 0) {
      if (state.progTimer) { clearInterval(state.progTimer); state.progTimer = null; }
      state.lookingUp = false;
      $('lookupMsg').textContent = '✅ 互查完成！可在下方查看明细并导出对照表。';
      $('phaseText').textContent = '完成';
      updateButtons();
      refreshHealth();
    }
  }

  // ---- 结果表 ----
  function renderResults() {
    const body = $('resultBody');
    const note = $('renderNote');
    if (!state.results.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="7">暂无结果 —— 完成登录、上传名单并开始互查后，这里会逐行显示。</td></tr>';
      note.classList.add('hidden');
    } else {
      const MAX = 1000;
      const show = state.results.slice(0, MAX);
      body.innerHTML = show.map(rowHtml).join('');
      if (state.results.length > MAX) {
        note.textContent = '表格仅展示前 ' + MAX + ' 行，完整结果请导出 Excel / CSV（共 ' + state.results.length + ' 行）。';
        note.classList.remove('hidden');
      } else note.classList.add('hidden');
    }
    renderStats();
    updateExportButtons();
  }

  function rowHtml(r) {
    const inp = r.input || {};
    const inputParts = [];
    if (inp.id) inputParts.push('🆔 ' + escapeHtml(inp.id));
    if (inp.douyin) inputParts.push('🎵 ' + escapeHtml(inp.douyin));
    if (inp.name) inputParts.push('👤 ' + escapeHtml(inp.name));
    const status = r.found
      ? '<span class="tag-ok">成功</span>'
      : '<span class="tag-fail">未检索到</span>';
    return '<tr>' +
      '<td class="col-row">' + r.row + '</td>' +
      '<td class="cell-input">' + inputParts.map(p => '<div>' + p + '</div>').join('') + '</td>' +
      '<td>' + escapeHtml(r.douyin) + '</td>' +
      '<td>' + escapeHtml(r.id) + '</td>' +
      '<td>' + escapeHtml(r.name) + '</td>' +
      '<td>' + status + '</td>' +
      '<td>' + escapeHtml(VIA_LABEL[r.via] || '') + '</td>' +
      '</tr>';
  }

  function renderStats() {
    const okN = state.results.filter(r => r.found).length;
    $('statOk').textContent = okN;
    $('statFail').textContent = state.results.length - okN;
    $('statTotal').textContent = state.results.length;
  }
  function updateExportButtons() {
    const has = state.results.length > 0 && !state.lookingUp;
    $('exportXlsx').disabled = !has;
    $('exportCsv').disabled = !has;
    $('writebackBtn').disabled = !(has && state.source === 'base' && state.baseCtx);
  }

  // ---- 导出（口径与服务端 buildExportRows 一致）----
  function buildExport() {
    const headers = state.headers || [];
    const roles = classifyHeaders(headers);
    const finalHeaders = headers.slice();
    if (!roles.douyinH) finalHeaders.push('抖音号');
    if (!roles.idH) finalHeaders.push('星图ID');
    if (!roles.nameH) finalHeaders.push('达人名称');
    finalHeaders.push('状态', '匹配方式');

    const isEmpty = (v) => v == null || String(v).trim() === '';
    const rows = state.results.map((r) => {
      const o = {};
      headers.forEach(h => { o[h] = (r.orig && h in r.orig) ? r.orig[h] : ''; });
      const fill = (existingH, canonical, v) => {
        if (!v) { if (!existingH) o[canonical] = ''; return; }
        if (existingH) { if (isEmpty(o[existingH])) o[existingH] = v; } else o[canonical] = v;
      };
      fill(roles.douyinH, '抖音号', r.douyin);
      fill(roles.idH, '星图ID', r.id);
      fill(roles.nameH, '达人名称', r.name);
      o['状态'] = r.found ? '成功' : '未检索到';
      o['匹配方式'] = VIA_LABEL[r.via] || '';
      return o;
    });
    return { finalHeaders, rows };
  }

  function classifyHeaders(headers) {
    const douyinH = headers.find(h => /抖音号|抖音id|抖音账号|抖音|douyin|unique_?id/i.test(h)) || '';
    const idH = headers.find(h => h !== douyinH && /星图id|星图达人id|达人id|star_?id|author_?id|\bid\b|uid|(?:^|[\s_])编号$/i.test(h)) || '';
    const nameH = headers.find(h => h !== idH && h !== douyinH && /达人名称|达人名|昵称|名字|主播名|主播|账号名|name/i) || '';
    return { douyinH, idH, nameH };
  }

  $('exportXlsx').addEventListener('click', () => {
    const { finalHeaders, rows } = buildExport();
    const ws = XLSX.utils.json_to_sheet(rows, { header: finalHeaders });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '达人信息互查');
    XLSX.writeFile(wb, 'xc-id-lookup-对照表.xlsx');
    $('exportMsg').textContent = '✅ Excel 已导出。';
  });

  $('exportCsv').addEventListener('click', () => {
    const { finalHeaders, rows } = buildExport();
    const csv = [finalHeaders].concat(rows.map(o => finalHeaders.map(h => csvCell(o[h]))))
      .map(line => line.join(',')).join('\r\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'xc-id-lookup-对照表.csv';
    a.click();
    URL.revokeObjectURL(a.href);
    $('exportMsg').textContent = '✅ CSV 已导出。';
  });
  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  // ---- 模板下载（本地生成）----
  $('tplLink').addEventListener('click', (e) => {
    e.preventDefault();
    const ws = XLSX.utils.aoa_to_sheet([
      ['抖音号', '星图ID', '达人名称'],
      ['dy_demo001', '7299999999999999999', '示例达人A'],
      ['', '', '示例达人B'],
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '达人名单');
    XLSX.writeFile(wb, 'xc-id-lookup-名单模板.xlsx');
  });

  // ---- 多维表格来源（读取 / 写回）----
  function cellToText(v) {
    if (v == null) return '';
    if (typeof v === 'string' || typeof v === 'number') return String(v);
    if (Array.isArray(v)) {
      return v.map(x => {
        if (x == null) return '';
        if (typeof x === 'string') return x;
        return x.text || x.name || (x.link ? x.link : '');
      }).join('');
    }
    if (typeof v === 'object') return v.text || v.name || v.link || '';
    return '';
  }
  function parseBaseUrl(s) {
    let u;
    try { u = new URL(String(s).trim()); } catch (e) { return null; }
    const parts = u.pathname.split('/').filter(Boolean);
    const bi = parts.indexOf('base');
    const app = bi >= 0 ? parts[bi + 1] || '' : '';
    let table = u.searchParams.get('table') || '';
    if (!table && bi >= 0) table = parts[bi + 2] || '';
    const view = u.searchParams.get('view') || '';
    return app ? { app_token: app, table_id: table, view_id: view } : null;
  }
  async function callFaaS(payload) {
    const r = await fetch(FAAS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return await r.json();
  }
  function switchSource(src) {
    state.source = src;
    $('tabBase').classList.toggle('src-tab-on', src === 'base');
    $('tabExcel').classList.toggle('src-tab-on', src === 'excel');
    $('srcBase').classList.toggle('hidden', src !== 'base');
    $('srcExcel').classList.toggle('hidden', src !== 'excel');
  }
  $('tabBase').addEventListener('click', () => switchSource('base'));
  $('tabExcel').addEventListener('click', () => switchSource('excel'));

  let baseData = null;
  function fillMapSelect(sel, re, preferred) {
    sel.innerHTML = '<option value="">（不使用）</option>';
    baseData.allFields.forEach(f => {
      const o = document.createElement('option');
      o.value = f.name; o.textContent = f.name;
      sel.appendChild(o);
    });
    let chosen = '';
    if (preferred) chosen = preferred;
    if (!chosen) chosen = (baseData.allFields.find(f => re.test(f.name)) || {}).name || '';
    sel.value = chosen;
  }
  $('baseLoadBtn').addEventListener('click', async () => {
    const p = parseBaseUrl($('baseUrl').value);
    const msg = $('baseMsg');
    if (!p) { msg.textContent = '链接无法识别，请粘贴完整的多维表格链接（含 /base/）。'; return; }
    if (!p.table_id) { msg.textContent = '链接里没有 table（数据表），请在多维表格里点进具体数据表后再复制链接。'; return; }
    msg.textContent = '读取中…';
    $('baseLoadBtn').disabled = true;
    const r = await callFaaS({ stage: 'idlookup_base_records', app_token: p.app_token, table_id: p.table_id, view_id: p.view_id });
    $('baseLoadBtn').disabled = false;
    if (!r.ok) {
      if (/91402|permission|无权限|NOTEXIST/.test(String(r.error)))
        msg.textContent = '应用还没有这张表的访问权限：请在多维表格右上角「···」→「添加文档应用」里，把本工具对应的应用加为协作者（可联系渠道经理协助开通）。';
      else msg.textContent = '读取失败：' + r.error;
      return;
    }
    baseData = r;
    $('baseRowCount').textContent = r.records.length;
    fillMapSelect($('mapDy'), /抖音|douyin/i);
    fillMapSelect($('mapId'), /星图|达人id/);
    fillMapSelect($('mapNm'), /达人名称|名称|昵称|作者/);
    $('baseMap').classList.remove('hidden');
    msg.textContent = '';
  });

  $('baseUseBtn').addEventListener('click', () => {
    if (!baseData) return;
    const dyCol = $('mapDy').value, idCol = $('mapId').value, nmCol = $('mapNm').value;
    if (!dyCol && !idCol && !nmCol) { $('baseUseMsg').textContent = '请至少选择一列。'; return; }
    const items = [];
    baseData.records.forEach(rec => {
      const douyin = dyCol ? cleanHandle(cellToText(rec.fields[dyCol])) : '';
      const id = idCol ? cellToText(rec.fields[idCol]).replace(/\s+/g, '') : '';
      const name = nmCol ? cellToText(rec.fields[nmCol]).trim() : '';
      if (!douyin && !id && !name) return;
      const orig = {};
      if (dyCol) orig[dyCol] = douyin;
      if (idCol) orig[idCol] = id;
      if (nmCol) orig[nmCol] = name;
      items.push({ row: items.length + 1, recordId: rec.record_id, orig, id, douyin, name });
    });
    if (!items.length) { $('baseUseMsg').textContent = '没有可用数据行。'; return; }
    state.items = items;
    state.headers = [dyCol, idCol, nmCol].filter(Boolean);
    state.baseCtx = {
      app_token: baseData.app_token, table_id: baseData.table_id,
      mapping: { douyin: dyCol, starId: idCol, name: nmCol },
    };
    state.results = [];
    renderResults();
    updateButtons();
    $('baseUseMsg').textContent = '✅ 已载入 ' + items.length + ' 行，可直接点第 3 步开始互查。';
  });

  // ---- 一键写回多维表格 ----
  $('writebackBtn').addEventListener('click', async () => {
    const ctx = state.baseCtx;
    const msg = $('writebackMsg');
    if (!ctx) { msg.textContent = '当前不是多维表格来源。'; return; }
    const updates = state.results
      .filter(r => r.recordId && r.found && (r.id || r.douyin || r.name))
      .map(r => ({ record_id: r.recordId, values: { douyin: r.douyin, starId: r.id, name: r.name } }));
    if (!updates.length) { msg.textContent = '没有可写回的成功结果。'; return; }
    $('writebackBtn').disabled = true;
    msg.textContent = '写回中（' + updates.length + ' 条）…';
    const r = await callFaaS({
      stage: 'idlookup_base_writeback',
      app_token: ctx.app_token, table_id: ctx.table_id,
      mapping: ctx.mapping, updates,
    });
    if (r.ok) msg.textContent = '✅ 已写回 ' + r.updated + ' 行到多维表格，可回到表格查看。';
    else msg.textContent = '写回失败：' + r.error;
    updateExportButtons();
  });

  // ---- 启动 ----
  bindDropzone();
  refreshHealth();
  setInterval(refreshHealth, 4000);
})();
