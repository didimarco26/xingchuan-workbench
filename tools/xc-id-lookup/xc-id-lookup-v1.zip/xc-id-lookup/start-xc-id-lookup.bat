@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

cd /d "%~dp0"

echo ============================================
echo   Xingchuan ID Lookup v1.3.0
echo   Node dependencies are bundled - no
echo   network install needed. Uses your system
echo   Chrome / Edge for login (falls back to an
echo   on-page QR code if the browser is blocked).
echo ============================================
echo.

rem 1) Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found. Please install Node.js from https://nodejs.org
    echo         After installation, double-click this file again.
    echo.
    pause
    exit /b 1
)

echo [OK] Node.js found. Dependencies are bundled, no network install needed.
echo [INFO] Login uses your system Chrome / Edge; if it is blocked by policy,
echo        an on-page QR code is shown automatically (scan with Douyin app).
echo.

rem 2) Start the tool
echo ==================================================
echo  Xingchuan ID Lookup is running v1.3.0 (background service).
echo  Run from      : %~dp0
echo  Local service : http://127.0.0.1:7843
echo  The tool page opens automatically.
echo.
echo  4 STEPS:
echo    1. Keep this window open;
echo    2. Click the "Login to Xingtu" button on the tool page -
echo       a Chrome/Edge window opens for QR login; if blocked,
echo       a QR code is shown on the page (scan with Douyin app);
echo    3. Upload your influencer Excel (Douyin ID / Xingtu ID /
echo       name, any one or more columns);
echo    4. Click "Start Lookup", then export Excel / CSV.
echo.
echo  Keep this window open while using the tool.
echo  Close the window (or press Ctrl+C) to stop.
echo ==================================================
echo.
node xc-id-lookup.js

echo.
echo Tool exited. Press any key to close.
pause >nul
