# 本机工具 xc-tagger 安装、启动与排障

渠道经理的达人打标依赖其**本机运行**的 `xc-tagger` 小工具：它在本机 `127.0.0.1:7842` 起服务，用 Playwright 复用本机 Chrome 里已登录的巨量星图账号抓取达人数据。星图 Cookie / 登录态**只留在渠道经理自己电脑上**，不上传。

> Skill 所有对 `127.0.0.1:7842` 的调用都必须通过 `bash` 工具且设置 `run_device="local"`（在用户的 Mac/PC 上执行）；沙箱内访问不到用户本机。

## 一、判断工具状态

Skill 侧统一用 **curl** 探测（macOS / Windows 10+ 自带，不依赖 Node）：

```bash
curl -sS -m 8 -w "\nHTTP:%{http_code}\n" http://127.0.0.1:7842/health
```

- 返回 JSON 且 `loggedIn:true`（HTTP:200）→ 工具在线且星图已登录，可直接打标。
- `HTTP:000` / curl Exit 7（连不上）→ **工具未启动或未安装**，按下面「二、首次安装 / 三、日常启动」处理。
- 返回 JSON 但 `loggedIn:false` → 工具在线但星图未登录（或登录过期）。执行 `curl -sS -X POST http://127.0.0.1:7842/login` 会在本机唤起 Chrome 打开星图达人广场，请用户扫码后重新 health。

## 二、首次安装（仅一次）

前提：macOS / Windows 已装 **Node.js 18+**。先检查：

```bash
node -v
```

没有则引导用户到 https://nodejs.org 下载 LTS 版本一路下一步安装（Agent 不要替用户安装 Node）。

### macOS（当前连接设备为 Mac）

可直接用 local bash 帮用户下载解压到 `~/Downloads`：

```bash
cd ~/Downloads && curl -L -o xc-tagger-mac-v1.zip \
  https://didimarco26.github.io/xingchuan-workbench/tools/xc-tagger/xc-tagger-mac-v1.zip \
  && unzip -o xc-tagger-mac-v1.zip -d xc-tagger-pkg && ls -la xc-tagger-pkg
```

解压后得到 `xc-tagger/` 文件夹（含 `start-xc-tagger.command`、`xc-tagger.js`、`package.json` 等）。

然后让用户**双击 `start-xc-tagger.command`**（首次若提示「来自身份不明的开发者」：右键 → 打开 → 再点打开）。
首次启动会自动 `npm install` 并下载 Playwright Chromium（约 150MB，几分钟），随后自动弹出 Chrome 打开巨量星图达人广场，**用手机扫码 / 验证码登录一次**即可，登录态长期保存在工具目录的 `.xc-chrome-profile/` 内。

> 双击启动需要用户在自己的桌面会话操作（Agent 的 local bash 适合下载解压与探测，不适合长期占用一个前台 GUI 进程；不要用 local bash 直接 `node xc-tagger.js` 长跑，bash 调用结束进程可能被回收）。

命令行方式（用户偏好终端时）：在 `xc-tagger/` 目录执行

```bash
npm install
npx playwright install chromium
node xc-tagger.js
```

### Windows

下载 `https://didimarco26.github.io/xingchuan-workbench/tools/xc-tagger/xc-tagger-win-v1.zip`，解压后双击 `start-xc-tagger.bat`，流程同 Mac。

## 三、日常启动（每次打标前）

工具不是常驻服务。每次使用前：

1. 双击 `start-xc-tagger.command`（Mac）/ `start-xc-tagger.bat`（Win），或终端 `node xc-tagger.js`；
2. 看到窗口提示「✅ 检测到星图已登录，可直接使用」；
3. **保持黑窗口不要关**（关窗口即停服务），回到 Aime 对话继续。

打完标关闭黑窗口即可。

## 四、名单文件要求

- 格式 `.xlsx / .xls / .csv`，第一行为表头；
- 工具自动识别列：**达人ID 列**（列名含 `达人ID / 星图ID / ID / UID / 编号`，纯数字星图达人 ID，走批量接口，更快更准）或**昵称列**（列名含 `昵称 / 达人名 / 名字 / 账号名 / name / 主播`，走达人广场搜索）；
- 只有一列时：纯数字按达人 ID，否则按昵称；
- 单次打标上限 **1000 人**（工具内部截断），更大名单请拆分文件分批；
- 模板下载：`https://didimarco26.github.io/xingchuan-workbench/tools/xc-tagger/xc-influencer-template.xlsx`。

## 五、常见问题

| 现象 | 原因与处理 |
| --- | --- |
| health 连不上（HTTP:000 / curl Exit 7） | 工具未启动或黑窗口已关；双击启动脚本后重试。端口被占用时关掉占用 7842 的程序。 |
| tag 返回 HTTP:401 / `loggedIn:false` | 星图未登录或过期：`curl -sS -X POST http://127.0.0.1:7842/login` 唤起浏览器，用户扫码后重跑 tag（parse.json 可复用，无需重新上传名单）。 |
| 个别达人「未检索到」 | 昵称拼写不一致、达人未入驻星图；优先让服务商提供**达人 ID 列**。 |
| 抓取字段大面积为空 / 分层明显异常 | 星图接口字段可能变更。让用户在工具目录设 `XC_TAGGER_DEBUG=1` 重启工具（`XC_TAGGER_DEBUG=1 node xc-tagger.js`），打标后会落盘 `debug_*.json`，收集后反馈工具维护者校准字段映射。 |
| 首次双击 Mac 提示安全拦截 | 右键 `start-xc-tagger.command` →「打开」→ 弹窗再点「打开」（仅首次）。 |
| 想彻底退出星图登录 | 删除工具目录下 `.xc-chrome-profile/` 后重启。 |

## 六、安全边界（向用户说明）

- 服务只绑定 `127.0.0.1`，局域网其他机器访问不到；
- 不收集、不上传名单与登录数据，抓取与打分全部在用户本机完成；
- Skill 回传飞书多维表格的只有**打标结果**（昵称/ID/分层/评分等），且需用户确认后才发送。
