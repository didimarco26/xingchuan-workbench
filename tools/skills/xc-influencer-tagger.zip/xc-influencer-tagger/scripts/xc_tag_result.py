#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xc_tag_result.py — 星川达人打标结果处理（在 Aime 沙箱侧运行，纯标准库）

子命令：
  summary <tag.json>                       打印分层汇总 + 紧凑名单（供 Agent 转述）
  csv     <tag.json> <out.csv>             导出 BOM CSV（列对齐存量达人库）
  push    <tag.json> --name <服务商> [--file 文件名] [--source 来源]
                                           回传飞书多维表格「服务商达人打标记录」

tag.json 为本机 xc-tagger 工具 POST /tag 的响应（经共享目录回传到沙箱）。
"""
import argparse
import csv
import io
import json
import sys
import urllib.request

FAAS_URL = "https://magic.solutionsuite.cn/api/faas/vu19pYRBTEZ"
TIER_ORDER = ["标杆", "主力", "潜力", "储备"]
MEDAL = {"标杆": "🥇", "主力": "🥈", "潜力": "🥉", "储备": "⚪"}

CSV_COLUMNS = [
    "达人名称", "达人ID(星图)", "粉丝量级", "星川等级", "电商等级",
    "星图项目数", "星图消耗(元)", "分层", "评分", "主要标签",
    "人设标签", "内容形式", "打标依据",
]


def load_tag(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not data.get("ok"):
        raise SystemExit(f"❌ 打标响应不成功：{data.get('error', data)}")
    results = data.get("results") or []
    summary = data.get("summary") or {}
    return data, results, summary


def fmt_wan(yuan):
    yuan = float(yuan or 0)
    if yuan >= 10000:
        return f"{yuan/10000:.1f}万" if yuan < 1000000 else f"{yuan/10000:.0f}万"
    return f"{yuan:.0f}元" if yuan > 0 else "0"


def cmd_summary(path):
    data, results, summary = load_tag(path)
    total = data.get("total", len(results))
    print(f"打标完成：共 {total} 人，耗时数据来自本机 xc-tagger")
    print("分层汇总：" + "  ".join(
        f"{MEDAL[t]}{t} {summary.get(t, 0)}人" for t in TIER_ORDER))
    found = [r for r in results if r.get("found", True)]
    missing = [r for r in results if not r.get("found", True)]
    print(f"其中成功抓取 {len(found)} 人，未检索到 {len(missing)} 人\n")

    print("=== 打标名单（按评分降序，文本最多展示 150 人，完整名单见 CSV）===")
    for r in found[:150]:
        tier = r.get("tier", "储备")
        line = (
            f"{r.get('medal', MEDAL.get(tier, ''))}{tier}｜{r.get('name','')}｜"
            f"{r.get('score', 0)}分｜{r.get('sLevel') or '未分级'}｜"
            f"消耗{fmt_wan(r.get('consumption'))}｜项目{r.get('deliveries', 0)}个｜"
            f"{r.get('lLevel') or 'L-'}｜{r.get('fansTier') or '粉丝未知'}"
        )
        print(line)
    if len(found) > 150:
        print(f"…其余 {len(found)-150} 人见 CSV 文件")

    if missing:
        print("\n=== 未在星图检索到（请核对昵称/ID 或确认达人是否入驻星图）===")
        for r in missing:
            print(f"❓ {r.get('name','')} {('ID:'+r['id']) if r.get('id') else ''}".rstrip())


def csv_safe(v):
    s = str(v if v is not None else "")
    if s[:1] in ("=", "+", "-", "@"):
        s = "'" + s
    return s


def cmd_csv(path, out):
    _, results, _ = load_tag(path)
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(CSV_COLUMNS)
        for r in results:
            tier = r.get("tier", "储备")
            w.writerow([
                csv_safe(r.get("name", "")),
                csv_safe(r.get("id", "")),
                r.get("fansTier", ""),
                r.get("sLevel", ""),
                r.get("lLevel", ""),
                r.get("deliveries", 0),
                int(float(r.get("consumption") or 0)),
                f"{r.get('medal', MEDAL.get(tier, ''))}{tier}",
                r.get("score", 0),
                csv_safe("、".join(r.get("tags") or [])),
                csv_safe("、".join(r.get("persona") or [])),
                csv_safe("、".join(r.get("forms") or [])),
                csv_safe(r.get("reason", "")),
            ])
    print(f"✅ CSV 已导出：{out}（{len(results)} 行，UTF-8 BOM，Excel 可直接打开）")


def cmd_push(path, name, file_name, source):
    data, results, summary = load_tag(path)
    payload = {
        "stage": "tagger_record",
        "name": name[:60],
        "source": (source or "渠道经理Aime代打标")[:30],
        "fileName": (file_name or "")[:120],
        "results": results,
        "total": data.get("total", len(results)),
        "summary": {t: int(summary.get(t, 0)) for t in TIER_ORDER},
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        FAAS_URL, data=body,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            out = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print(f"❌ 回传失败：{e}")
        sys.exit(1)
    if out.get("ok") and out.get("data", {}).get("recorded"):
        rid = out["data"].get("rid", "")
        print(f"✅ 已写入飞书多维表格「服务商达人打标记录」（记录ID {rid}）")
    else:
        print(f"❌ 回传异常：{out}")
        sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_s = sub.add_parser("summary")
    p_s.add_argument("tag_json")

    p_c = sub.add_parser("csv")
    p_c.add_argument("tag_json")
    p_c.add_argument("out_csv")

    p_p = sub.add_parser("push")
    p_p.add_argument("tag_json")
    p_p.add_argument("--name", required=True, help="服务商名称")
    p_p.add_argument("--file", default="", help="原始名单文件名")
    p_p.add_argument("--source", default="渠道经理Aime代打标")

    args = ap.parse_args()
    if args.cmd == "summary":
        cmd_summary(args.tag_json)
    elif args.cmd == "csv":
        cmd_csv(args.tag_json, args.out_csv)
    elif args.cmd == "push":
        cmd_push(args.tag_json, args.name, args.file, args.source)


if __name__ == "__main__":
    main()
