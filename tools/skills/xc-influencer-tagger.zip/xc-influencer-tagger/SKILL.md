---
name: xc-influencer-tagger
description: 星川达人分层打标 · 渠道经理为服务商批量打标专用工具。通过渠道经理本机运行的 xc-tagger 工具（127.0.0.1:7842），复用其已登录的巨量星图账号，批量抓取达人名单中每位达人的星川等级、星图消耗、交付项目数、电商等级，按 80 分制自动打分并分为 🥇标杆/🥈主力/🥉潜力/⚪储备 四层，输出分层汇总、详细名单与 CSV，并可回传飞书多维表格留档。适用于「给服务商达人打标」「达人名单分层」「星图达人评分」「这批达人分个层」「打标结果回传」等场景。
author: rihui
---

# 星川达人分层打标（xc-influencer-tagger）

帮渠道经理把服务商提交的达人名单（Excel/CSV）批量打分、分层，产出可交付的 CSV 与汇总。

## 打标口径（工具自动计算，用于向用户解释结果）

满分 80 分，四个维度：

| 维度 | 满分 | 分档 |
| --- | --- | --- |
| 星川等级 S | 30 | S5=30 / S4=25.5 / S3=21 / S2=15 / S1=9 / S0=4.5 |
| 交付项目数 | 20 | >50=20 / 21–50=15 / 6–20=10 / 1–5=5 / 0=0 |
| 星图消耗（元） | 20 | >100万=20 / 10–100万=16 / 1–10万=12 / 0.1–1万=8 / 0=0 |
| 电商等级 L | 10 | L3+=10 / L2=7 / L1=4 / L0=1 |

分层：**≥60 🥇标杆｜≥40 🥈主力｜≥20 🥉潜力｜<20 ⚪储备**。

## 两条铁律

1. **所有对 `127.0.0.1:7842` 的调用必须在用户本机执行**——用 `bash` 工具并设置 `run_device="local"`。沙箱访问不到用户电脑，在沙箱 curl 本机地址是无效操作。
2. **文件靠共享目录桥接**：用户上传的名单在沙箱，本机工具只认 PC 文件系统。通过系统 [Mount Context] 的挂载目录中转（沙箱路径 ↔ PC 路径指向同一份文件）。本机工具的安装/启动/排障详见 [local-tool-setup.md](references/local-tool-setup.md)。

本机侧调用统一用 **curl**（macOS / Windows 10+ 自带，不依赖 Node）；沙箱侧结果处理用本 Skill 自带的 Python 脚本（纯标准库）。

## 工作流程

### 第 0 步：确认服务商名称与名单

开始前问清（或从用户消息中提取）**服务商名称**，后续汇总命名与回传表格都要用。若用户尚未上传名单，提示其准备 Excel/CSV（含「达人ID/星图ID」列最佳，纯昵称列也可；模板 https://didimarco26.github.io/xingchuan-workbench/tools/xc-tagger/xc-influencer-template.xlsx ）。

### 第 1 步：准备共享目录（沙箱侧）

从 [Mount Context] 取挂载目录的两个路径（记为 `SANDBOX_SHARE` 与 `PC_SHARE`；当前 macOS 挂载点形如 `/private/tmp/aime-agent-shared-dir/<id>`）。不确定时用 local bash 确认：`ls -d /private/tmp/aime-agent-shared-dir/*/ | tail -1`。

沙箱侧建工作目录并放入名单：

```bash
mkdir -p "<SANDBOX_SHARE>/xc-tagger-work"
cp "<上传名单的沙箱路径>" "<SANDBOX_SHARE>/xc-tagger-work/list.xlsx"
```

### 第 2 步：健康检查（local）

用 local bash 执行（curl 自带，无需 Node）：

```bash
curl -sS -m 8 -w "\nHTTP:%{http_code}\n" http://127.0.0.1:7842/health
```

判读：
- 返回 JSON 且 `loggedIn:true` → 工具在线且星图已登录，继续第 3 步。
- `HTTP:000`（curl 连不上 / Exit 7）→ **工具未启动或未安装**。按 [local-tool-setup.md](references/local-tool-setup.md) 处理：可先用 local bash 帮用户下载解压工具包到 `~/Downloads`，再请用户**双击启动脚本并扫码登录星图**（需本机 Node 18+；工具的安装是一次性环境准备，Agent 不替用户安装 Node），完成后重新 health。
- 返回 JSON 但 `loggedIn:false` → 工具在线但星图未登录/过期：`curl -sS -X POST http://127.0.0.1:7842/login`（local）唤起浏览器，请用户在弹出的 Chrome 扫码/验证码登录，确认后重新 health。

### 第 3 步：解析名单（local）

```bash
curl -sS -m 30 -X POST --data-binary @"<PC_SHARE>/xc-tagger-work/list.xlsx" \
  "http://127.0.0.1:7842/parse?fn=list.xlsx" \
  -o "<PC_SHARE>/xc-tagger-work/parse.json" -w "HTTP:%{http_code}\n"
```

- HTTP:200：用 read 工具读沙箱侧 `<SANDBOX_SHARE>/xc-tagger-work/parse.json`，向用户展示**识别到达人数量**（`count` 字段）与表头，请用户确认后再打标。
- HTTP:422：未识别到 ID/昵称列——提示名单需含「达人ID/星图ID」或「昵称/达人名」列，附上模板链接，请用户调整后重传（替换 list.xlsx 重跑本步）。

### 第 4 步：批量打标（local，长任务）

parse.json 本身含 `items` 数组，直接作为 /tag 请求体（无需转换）：

```bash
curl -sS -X POST -H "Content-Type: application/json" \
  --data-binary @"<PC_SHARE>/xc-tagger-work/parse.json" \
  http://127.0.0.1:7842/tag \
  -o "<PC_SHARE>/xc-tagger-work/tag.json" -w "HTTP:%{http_code}\n"
```

用 `run_device="local"` 调用，bash 超时设为 -1（长请求会自动转后台），再用 wait_async_task 等待。打标耗时：ID 名单约 1 秒/50 人；昵称名单约 0.5 秒/人，数百人数分钟。期间提示用户**保持 xc-tagger 黑窗口打开、星图登录态有效**。

- HTTP:200 → 第 5 步。
- HTTP:401（响应 `loggedIn:false`）→ 星图登录过期：回第 2 步 login 扫码后重跑（parse.json 可复用，无需重新上传）。
- HTTP:000 → 工具中途退出，请用户确认黑窗口仍在运行后重跑。

### 第 5 步：汇总与交付（沙箱侧）

```bash
# 分层汇总 + 紧凑名单（文本，供转述）
python3 user_skills/xc-influencer-tagger/scripts/xc_tag_result.py summary "<SANDBOX_SHARE>/xc-tagger-work/tag.json"

# 导出 CSV（UTF-8 BOM，Excel 直接打开；13 列对齐存量达人库口径）
python3 user_skills/xc-influencer-tagger/scripts/xc_tag_result.py csv "<SANDBOX_SHARE>/xc-tagger-work/tag.json" "<workspace>/<服务商名>_达人打标_<YYYYMMDD>.csv"
```

交付内容：
- **分层汇总**：🥇标杆/🥈主力/🥉潜力/⚪储备 各几人、成功抓取/未检索到各几人；
- **重点名单**：标杆、主力达人逐人列出（昵称/评分/星川等级/星图消耗/项目数）；
- **未检索到达人**：逐个列出，请用户核对昵称/ID 或确认是否入驻星图（建议服务商补达人 ID 后重跑这部分）；
- **CSV 文件**：以 Markdown 链接给出，含全部达人完整明细。

### 第 6 步：可选回传飞书多维表格

询问用户是否留档，确认后沙箱侧执行（写入飞书多维表格「服务商达人打标记录」，仅打标结果，不含任何登录态）：

```bash
python3 user_skills/xc-influencer-tagger/scripts/xc_tag_result.py push "<SANDBOX_SHARE>/xc-tagger-work/tag.json" --name "<服务商名称>" --file "<原始名单文件名>"
```

成功返回记录 ID。用户未明确同意前不要回传。

## 边界与注意

- 单次打标上限 **1000 人**（工具内部截断）；超量名单拆文件分批，结果分别导出。
- 打标抓取全在用户本机完成，星图 Cookie 不离开用户电脑；回传飞书的只有结果数据且需用户确认。
- 共享目录 `xc-tagger-work/` 内中间文件（list.xlsx/parse.json/tag.json）任务结束后可保留或清理。
- 字段大面积异常（消耗/等级普遍为空）多为星图接口字段变更，按 [local-tool-setup.md](references/local-tool-setup.md) 排障节让用户开 `XC_TAGGER_DEBUG=1` 重跑并收集 `debug_*.json` 反馈维护者。
