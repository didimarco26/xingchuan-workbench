# 数据源说明：星川爆款底池

## 一、在线工具（优先）

**星川内容分析工作台**：https://df2c92d14dcb.aime-site.bytedance.net

- 已内置底池快照（随工作台版本更新），无需取数即可查看：六组 KPI、底池结论、四维分布、公式链 TOP3、对标案例 TOP10。
- 服务端 AI 能力（链接识别、方向推荐、痛买放转脚本、热点榜、视频拆解）由星川 FaaS 提供，网页零 Key。
- 适合交互分析与一线服务商自助使用；需要自定义口径或留档时再走 Base 取数。

## 二、飞书多维表格（自定义口径/全量取数）

主 Base：`Ph1QbuxpmapknksJdoqcQschnZe`（星川AI工作台 / 主多维表格）

| 表 | table_id | 内容 |
|-|-|-|
| 【参考池1】星川爆款案例库 | `tblCm5EzIYaSPvSg` | 逐条爆款素材的结构化拆解 |
| 【参考池2】星川跑量公式库 | `tblyVydOvbDwKsoH` | 环节级跑量公式链 |

> 表内记录持续增长，条数以实查为准，记忆中的历史条数仅作量级参考。

使用 `lark-base` skill 读取，优先用筛选/视图/聚合，不要全量导出后本地估算。

### 案例库核心字段口径

| 字段 | 含义 |
|-|-|
| title | 视频标题/口播首句 |
| hashtags | 话题标签（多值） |
| industry | 旧 5 行业口径 |
| category / productSubCategory | 一级品类 / 细分类目 |
| creativeDirection | 创意方向（题材标签） |
| brand / productName | 品牌 / 品名 |
| videoType | 内容形式：桌拍 / 真人口播 |
| openingHookLevel1 / openingHookLevel2 | 一级/二级开场钩子类型 |
| hook_line | 前 3 秒口播原文 |
| analysis_pre3s_hook / analysis_middle_structure / analysis_ending | 开头钩子 / 中段结构 / 结尾转化拆解 |
| hot_analysis | 爆款逻辑一句话分析 |
| videoLink / coverImageUrl | 原视频链接 / 封面 |
| metrics.xingchuanConsumptionLevel | 星川消耗量级（元，数值型字符串） |

### 公式库核心字段口径

| 字段 | 含义 |
|-|-|
| formula | 公式链（手法用「+」连接，顺序≈镜头顺序） |
| formulaSteps | 环节数组：tag1（手法标签）+ sellingPoint（具体做法） |
| xingchuanCostYuan | 该公式对应星川消耗（元） |
| industry / category / productSubCategory / creativeDirection | 行业、品类、方向标签 |

## 三、行业映射（新 7 → 旧 5）

底池按旧 5 行业建库，商品输入按新 7 行业收集，按下表映射：

| 新行业 | 旧行业 |
|-|-|
| 个护美妆 | 个护美妆 |
| 食品饮料 | 食品饮料 |
| 保健食品 | 食品饮料（并入） |
| 母婴宠物 | 母婴宠物 |
| 服饰鞋包 | 服饰&家居电器 |
| 家居家清 | 家清纸品 |
| 其他 | 全行业池兜底，并标注「跨行业参考」 |

## 四、取数与统计纪律

1. 行业圈池后再做细分类目匹配；结构统计基于行业大盘（样本稳），细分子集用于对标排序。
2. 消耗字段是字符串，先转数值；空值/非数按 0 处理，不计入中位数样本。
3. 多品牌限量：案例展示同一品牌不超过 2 条，避免大品牌霸榜。
4. 统计口径写进交付物（样本数、时间范围、行业），让结论可复核。
5. 对外材料只放脱敏后的案例标题/链接与汇总数据，不放 Base token 与内部字段名。
