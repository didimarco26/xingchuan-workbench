#!/bin/bash
# ============================================================
# 星川服务商达人打标工具 · Mac 一键启动
# 双击本文件即可运行（前提：已安装 Node.js 18+，https://nodejs.org）
# 工具以【无头模式】后台运行，不会弹出浏览器窗口；登录请在工作台「导入 Cookie」。
# ============================================================

cd "$(dirname "$0")" || exit 1
RUN_DIR="$(pwd)"

echo "============================================"
echo "   星川打标工具启动中...（无头模式，不弹浏览器窗口）"
echo "   运行目录：$RUN_DIR"
echo "============================================"
echo ""

# 1) 检测 Node.js
if ! command -v node >/dev/null 2>&1; then
  echo "❌ 未检测到 Node.js，请先安装 Node.js：https://nodejs.org"
  echo "   安装完成后，重新双击本脚本即可。"
  osascript -e 'display dialog "未检测到 Node.js，请先安装 Node.js：" & return & "https://nodejs.org" & return & return & "安装完成后重新双击本脚本即可。" with title "星川打标工具" buttons {"确定"} default button 1 with icon caution' >/dev/null 2>&1
  echo ""
  echo "按任意键关闭窗口..."
  read -n 1
  exit 1
fi

# 2) 首次运行自动安装依赖
if [ ! -d node_modules ]; then
  echo "⏳ 首次运行，正在自动安装依赖（npm install），请耐心等待..."
  npm install
  if [ $? -ne 0 ]; then
    echo ""
    echo "❌ 依赖安装失败，请检查网络后重新双击本脚本。"
    echo "按任意键关闭窗口..."
    read -n 1
    exit 1
  fi
fi

# 3) 确保 Playwright 自带 Chromium 已安装（每次启动都执行，已装则秒过，未装则自动下载）
echo "⏳ 正在验证 Playwright Chromium 浏览器..."
npx playwright install chromium
if [ $? -ne 0 ]; then
  echo "⚠️ 浏览器下载失败，请检查网络后重新双击本脚本。"
  echo "按任意键关闭窗口..."
  read -n 1
  exit 1
fi
echo "   Chromium 已就绪。"

# 4) 启动工具（无头后台运行，不弹浏览器窗口）
echo ""
echo "=================================================="
echo "  星川打标工具已启动（无头模式，不弹浏览器窗口）"
echo "  本地服务：http://127.0.0.1:7842"
echo "  工作台网页：https://didimarco26.github.io/xingchuan-workbench/"
echo ""
echo "  登录方式（无头模式不弹窗扫码）："
echo "   1) 在你自己的浏览器打开 https://www.xingtu.cn/ad/creator/square 并登录；"
echo '   2) 用 Cookie-Editor（或 EditThisCookie）扩展把 xingtu.cn 的 Cookie 导出为 JSON；'
echo "   3) 粘贴到工作台「导入 Cookie」框即可（Cookie 只存本机 .xc-cookies.json，不上传）。"
echo ""
echo "  使用过程中请保持本窗口打开，关闭窗口即停止工具"
echo "=================================================="
echo ""
node xc-tagger.js

echo ""
echo "工具已退出，按任意键关闭窗口..."
read -n 1
