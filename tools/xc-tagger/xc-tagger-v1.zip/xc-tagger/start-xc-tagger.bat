@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

cd /d "%~dp0"

echo ============================================
echo   Xingchuan Tagger - starting...
echo   (headless mode, no browser window pops up)
echo ============================================
echo.

rem 1) Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found. Please install Node.js from https://nodejs.org
    echo         After installation, double-click this file again.
    echo.
    pause
    exit /b 1
)

rem 2) First run: install dependencies automatically
if not exist node_modules (
    echo First run: installing dependencies, please wait...
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERROR] Dependency installation failed. Check your network and double-click again.
        echo.
        pause
        exit /b 1
    )
)

rem 3) Ensure Playwright's OWN Chromium is installed (run every time - already installed = a few seconds)
echo Checking Playwright Chromium browser...
call npx playwright install chromium
if errorlevel 1 (
    echo.
    echo [ERROR] Chromium download failed. Check your network and double-click again.
    echo.
    pause
    exit /b 1
)
echo [OK] Chromium ready.

rem 4) Start the tool (runs headless in the background; no Chrome window)
echo.
echo ==================================================
echo  Xingchuan Tagger is running (HEADLESS, no popup).
echo  Run from      : %~dp0
echo  Local service : http://127.0.0.1:7842
echo  Workbench page: https://didimarco26.github.io/xingchuan-workbench/
echo.
echo  LOGIN (no QR-code window):
echo    1. Open https://www.xingtu.cn/ad/creator/square in your own browser and log in;
echo    2. Use the "Cookie-Editor" (or EditThisCookie) extension to export
echo       the xingtu.cn cookies as JSON;
echo    3. Paste the JSON into the workbench "Import Cookie" box.
echo    (Cookies are stored locally in .xc-cookies.json, never uploaded.)
echo.
echo  Keep this window open while using the tool.
echo  Close the window (or press Ctrl+C) to stop.
echo ==================================================
echo.
node xc-tagger.js

echo.
echo Tool exited. Press any key to close.
pause >nul
